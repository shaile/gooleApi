export const jwtConstants = {
    secret: 'secretKey',
  };